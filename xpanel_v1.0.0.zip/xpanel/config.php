<?php

	// XPanel Admin UserName and Admin Password
	$ADMIN_USER = 'admin';
	$ADMIN_PASS = 'admin';

	// Database config | Do not change if you don't know
	$XP_DB_HOST = 'localhost';
	$XP_DB_NAME = 'asteriskcdrdb';
	$XP_DB_USER = 'root';
	$XP_DB_PASS = 'password';

	// Asterisk Call Records folder | Do not change if you don't know
	$WAV_FOLDER = '/var/spool/asterisk/monitor';
