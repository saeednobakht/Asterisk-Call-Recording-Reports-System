module.exports = require('./build/mediaelement-and-player.js');
